<?php 

// Variable donde declaramos la hora de apertura del negocio
$hora_de_apertura = "09:00";

// Variable donde declaramos la hora de cierre del negocio
$hora_de_cierre = "17:00";




